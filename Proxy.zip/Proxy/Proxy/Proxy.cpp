// Proxy.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include "framework.h"
#include "Proxy.h"
#include <afxsock.h>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <conio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

#define PROXY_PORT 8888
#define HTTP_PORT 80

#define null NULL

#define BYTE_STREAM 1
#define TEXT_STREAM 2

#define CHUNKED 1
#define LENGTH 2

vector<string> blacklist;
vector<string> bin_ext;
string forbidden403 = " Forbidden\r\nConnection: close\r\n\r\n";
string htmlrespond = "<p><span style=\"color: #ff0000;\">403</span> <span style=\"color: #3366ff;\">ACCESS FORBIDDEN</span></p>\r\n<p>You do not have permision to access this website</p>\r\n\r\n";
string htmlerrip = "<p>ERROR!</p>\r\n<p>Can not get ip!</p>\r\n\r\n";

typedef struct connectData
{
	SOCKET sClient;
	SOCKET sServer;
	bool is_cache;
	char file[1024];
} DATA, *pDATA;

struct date
{
	int day, month, year;
};

struct cacheInfo
{
	char file[1024];
	bool is_cache;
};

struct recvDataInfo
{
	int stream;//luong nhan du lieu <BYTE_STREAM, TEXT_STREAM>
	int way; // <CHUNKED, khac>
	long long length; // Do dai
};

void InitServer(); 

DWORD WINAPI HandlerEvent(LPVOID arg);

DWORD WINAPI HandlerBrowserServer(LPVOID arg);

string getRequest(CSocket& connector);

string getDataByChar(CSocket& connector);

char* getIP(const char* host);

char* getHostServer(const char* str);

bool isBannedHost(const char* host);

string getProtocol(string request);

wchar_t* convertCharArrayToLPCWSTR(const char* charArray);

string recieveHeader(CSocket& connector);

cacheInfo isCache(string str);

recvDataInfo getDataInfo(string str, cacheInfo CacheInfo);

string replace(string str);

bool isBinaryFile(string str);

char* toCharArray(string str);

void Transfer(CSocket& client, CSocket& server, cacheInfo info, recvDataInfo dataInfo);

long long getLength(string str);

date getSystemDate();

int main()
{
	
	int nRetCode = 0;

	HMODULE hModule = ::GetModuleHandle(nullptr);

	if (hModule != nullptr)
	{
		// initialize MFC and print and error on failure
		if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0))
		{
			// TODO: code your application's behavior here.
			wprintf(L"Fatal Error: MFC initialization failed\n");
			nRetCode = 1;
		}
		else
		{
			// TODO: code your application's behavior here.
			if (AfxSocketInit() == FALSE)
			{
				return FALSE;
			}
			CSocket proxy;
			if (proxy.Create(PROXY_PORT, SOCK_STREAM, NULL) == 0)
			{
				return FALSE;
			}
			InitServer();
			SOCKET* hSocket = new SOCKET;
			*hSocket = proxy.Detach();
			DWORD ID;
			HANDLE handle;
			handle = CreateThread(null, 0, HandlerEvent, hSocket, 0, &ID);
			while (handle == INVALID_HANDLE_VALUE)
			{
				handle = CreateThread(null, 0, HandlerEvent, hSocket, 0, &ID);
			}
			// server se chay mai mai
			HANDLE MAINHANDLE;
			MAINHANDLE = CreateEvent(null, true, false, null);
			while (MAINHANDLE == INVALID_HANDLE_VALUE)
			{
				MAINHANDLE = CreateEvent(null, true, false, null);
			}
			WaitForSingleObject(MAINHANDLE, INFINITE);
		}
	}
	else
	{
		// TODO: change error code to suit your needs
		wprintf(L"Fatal Error: GetModuleHandle failed\n");
		nRetCode = 1;
	}

	return nRetCode;
}

// xu li su kien ket noi tu browser den proxy va gui request cho webserver
DWORD WINAPI HandlerEvent(LPVOID arg)
{
	SOCKET* hConnect = new SOCKET;
	hConnect = (SOCKET*)arg;
	CSocket connector;
	connector.Attach(*hConnect);
	connector.Listen(); // lang nghe
	CSocket connected;
	if (connector.Accept(connected)) // nhan 1 ket noi
	{
		// Tao 1 thread de tiep tuc lang nghe -> de quy
		// xin cap phat vung nho heap
		SOCKET* newConnect = (SOCKET*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(*hConnect));
		DWORD id;
		HANDLE h;
		newConnect = hConnect;
		h = CreateThread(null, 0, HandlerEvent, newConnect, 0, &id);

		// Xu li socket hien tai 
		// Da chap nhan ket noi voi browser
		string request = getRequest(connected);
		if (request == "")  //khong con nhan request nua thi dong ket noi
		{
			connected.Close();
		}
		else // co request
		{
			// khong chap nhan request dang CONNECT
			if (strncmp(request.c_str(), "CONNECT", 7) == 0)
			{
				// gui ve loi 403
				string http = getProtocol(request);
				string http403 = http + forbidden403;
				connected.Send(http403.c_str(), http403.length(), 0);
				connected.Close();
			}
			else
			{
				char* host = getHostServer(request.c_str());
				char* ip = getIP(host);
				if (ip == null || strcmp(ip, "") == 0)
				{
					// neu ko tim duoc ip
					// gui loi IP error
					string http = getProtocol(request);
					string http403 = http + forbidden403;
					connected.Send(http403.c_str(), http403.length(), 0);
					connected.Send(htmlerrip.c_str(), htmlerrip.length(), 0);
					connected.Close();
				}
				else if (isBannedHost(host))
				{
					// neu la web trong blacklist
					// gui 403 access forbidden
					string http = getProtocol(request);
					string http403 = http + forbidden403;
					connected.Send(http403.c_str(), http403.length(), 0);
					connected.Send(htmlrespond.c_str(), htmlrespond.length(), 0);
					connected.Close();
				}
				else // moi thu deu on
				{
					CSocket server;
					server.Create(); // tao 1 socket -> ket noi toi webserver
					if (server.Connect(convertCharArrayToLPCWSTR(ip), HTTP_PORT) >= 0) // ket noi duoc
					{
						server.Send(request.c_str(), request.length(), 0); // gui request
						if (strncmp(request.c_str(), "POST ", 5) == 0) // neu la post thi nhan tiep tu browser
						{
							long long length = getLength(request);
							long long nByteRecv = 0;
							int tmp = 0;
							char c = 0;
							while (nByteRecv < length)
							{
								tmp = connected.Receive((char*)& c, 1, 0);
								if (tmp > 0)
								{
									nByteRecv += tmp;
									server.Send(&c, 1, 0);
									c = 0;
								}
							}
						}
						// tinh toan cache
						cacheInfo* info = &isCache(request);
						// Tao 1 tieu tinh moi
						// y nghia la se cho toi khi xu li request xong
						DWORD ThreadID;
						HANDLE handle;
						pDATA PAIR = (pDATA)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(DATA));
						PAIR->sClient = connected.Detach();
						PAIR->sServer = server.Detach();
						PAIR->is_cache = info->is_cache;
						strcpy(PAIR->file, info->file);
						handle = CreateThread(null, 0, HandlerBrowserServer, PAIR, 0, &ThreadID);
						if (handle)
						{
							WaitForSingleObject(handle, INFINITE); // wait
							HeapFree(GetProcessHeap(), 0, PAIR);
							server.Close();
							connected.Close();
						}
					}
				}
			}
		}
		// doi luong goi de quy o tren lam xong
		WaitForSingleObject(h, INFINITE);
		HeapFree(GetProcessHeap(), 0, newConnect);
		newConnect = null;
	}

	return 0;
}

// Lay request tu browser
string getRequest(CSocket& connector)
{
	string recvedRequest = "";
	recvedRequest += getDataByChar(connector);
	return recvedRequest;
}

// lay du lieu tung ki tu
// tham khao : http://diendan.congdongcviet.com/threads/t7362::lap-trinh-mang-thu-vien-winsock-tren-visual-cpp.cpp
string getDataByChar(CSocket& connector)
{
	string buf = "";
	bool endHeader = false, done = false;
	char HeaderResponse;
	int nByteRevc;
	while (!done) {
		nByteRevc = connector.Receive((char*)& HeaderResponse, 1, 0);
		if (nByteRevc <= 0)    // Loi
			done = true;
		else
		{
			buf += HeaderResponse;
			switch (HeaderResponse) {
			case '\r':
				break;
			case '\n': // Neu gap "\n\n" hay "\n\r\n" thi ket thuc Header
				if (endHeader == true) {
					done = true;
				}
				endHeader = true;
				break;
			default:
				endHeader = false;
				break;
			}
		}
	}
	return buf;
}

//lay server can truy cap
char* getHostServer(const char* str)
{
	// tim cho dau tien xuat hien chuoi nay
	const char* f = strstr(str, "Host: ");
	if (f != null)
	{
		int n = strlen(f);
		string kq = "";
		for (int i = 0; i < n; i++) // lay du lieu den khi gap \r\n
		{
			if (f[i + 6] == '\r' && f[i + 7] == '\n')
			{
				break;
			}
			else
			{
				kq += f[i + 6];
			}
		}
		return toCharArray(kq);
	}
	return null;
}

// lay ip.
// thma khao tren stackoverflow link ben duoi
char* getIP(const char* host)
{
	int iplen = 15;
	char* ip = new char[iplen + 1];
	memset(ip, 0, iplen + 1);
	struct hostent* hent = gethostbyname(host);
	if (hent == null)
	{
		return null;
	}
	//inet_ntop(AF_INET, (void*)hent->h_addr_list[0], ip, iplen);
	ip = inet_ntoa(**(in_addr**)hent->h_addr_list); // ref: https://stackoverflow.com/questions/9400756/ip-address-from-host-name-in-windows-socket-programming
	return ip;
}

// co nam trong blacklist hay khong
bool isBannedHost(const char* host)
{
	int n = blacklist.size();
	string s1, s2;
	for (int i = 0; i < n; i++)
	{
		if (strlen(host) > blacklist[i].length())
		{
			s1 = string(host);
			s2 = blacklist[i];
		}
		else
		{
			s2 = string(host);
			s1 = blacklist[i];
		}
		if (strstr(s1.c_str(), s2.c_str()) != NULL)
		{
			return true;
		}
	}
	return false;
}
// HTTP ver may
string getProtocol(string str)
{
	if (strstr(str.c_str(), "HTTP/1.0") != null)
		return "HTTP/1.0";
	return "HTTP/1.1";
}
// cua thay
wchar_t* convertCharArrayToLPCWSTR(const char* charArray)
{
	wchar_t* wString = new wchar_t[4096];
	MultiByteToWideChar(CP_ACP, 0, charArray, -1, wString, 4096);
	return wString;
}

// xu li giua browser va server
DWORD WINAPI HandlerBrowserServer(LPVOID arg)
{
	pDATA p = (pDATA)arg;
	CSocket browser;
	CSocket server;
	cacheInfo info;
	info.is_cache = p->is_cache;
	strcpy(info.file,p->file);
	browser.Attach(p->sClient);
	server.Attach(p->sServer);
	string header = recieveHeader(server); // nhan header tu server

	browser.Send(header.c_str(), header.length(), 0); // gui lai cho browser

	recvDataInfo dataInfo = getDataInfo(header, info);
	if (info.is_cache == false) // cache == false
	{
		if (info.file != "") // chua cache thi cache
		{
			date sysdate = getSystemDate();
			fstream f(info.file, ios::out);
			f << sysdate.day << " " << sysdate.month << " " << sysdate.year << endl;
			f << header;
		}
	}

	if (dataInfo.length != -2)//error no data // neu == -2 du lieu chi co header nen khong can lam nua
	{
		Transfer(browser, server, info, dataInfo);
	}

	return 0;
}

//nhan header tu webserver
string recieveHeader(CSocket& connector)
{
	string header = getDataByChar(connector);
	return header;
}

// lay ngay he thong
date getSystemDate()
{
	time_t now = time(0);
	tm* t = localtime(&now);
	date d;
	d.year = 1900 + t->tm_year;
	d.month = 1 + t->tm_mon;
	d.day = t->tm_mday;
	return d;
}

//lay thong tin cache
cacheInfo isCache(string str)
{
	cacheInfo info;
	if (strncmp(str.c_str(), "POST ", 5) == 0) //POST khong cache
	{
		strcpy(info.file , "");
		info.is_cache = false;
	}
	else //GET
	{
		int n = str.find_first_of(" ");
		int m = str.find_first_of(" ", n + 1);
		char* host = getHostServer(str.c_str());
		string s = str.substr(n, m - n); // chuoi duong dan browser yeu cau lay du lieu

		/*string ext = s.substr(s.find_last_of("."), s.length() - s.find_last_of("."));
		if (ext.length() > 5)
		{
			strcpy(info.file, "");
			info.is_cache = false;
			return info;
		}*/

		/*if (isBinaryFile(ext))
		{
			strcpy(info.file ,"");
			info.is_cache = false;
			return info;
		}*/

		// neu ton tai du lieu lay la file html, js, css thi cache

		if (strstr(s.c_str(), ".html") == null &&
			strstr(s.c_str(), ".js") == null && strstr(s.c_str(), ".css") == null)
		{
			strcpy(info.file, ""); // file == "" nghia la ko cache
			info.is_cache = false;
			return info;
		}

		// quyet dinh cache hay khong
		s = replace(s); // sua ten file cache cho hop le
		string filename = string(host) + "_" + s + ".CACHED";
		fstream f(filename, ios::in);
		date sysdate = getSystemDate();
		date cacheDate;
		// mo coi co file chua
		// chua co file tuc la chua cache
		if (!f.is_open())
		{
			strcpy(info.file,filename.c_str()); //file can cache
			info.is_cache = false; // nghia la chua cache
			return info;
		}
		else // co file cache
		{
			// kiem tra cache con han su dung hay khong
			f >> cacheDate.day;
			f >> cacheDate.month;
			f >> cacheDate.year;
			if (sysdate.day == cacheDate.day && sysdate.month == cacheDate.month && sysdate.year == cacheDate.year)
			{
				strcpy(info.file,filename.c_str());
				info.is_cache = true;
				return info;
			}
			// het han
			strcpy(info.file, filename.c_str()); // se lu lai du lieu
			info.is_cache = false; // dat co la chua cache
			return info;
		}
	}
}

//thay the cac ki tu khong duoc phep co mat trong ten file (quy dinh cua windows) = dau "_"
string replace(string str)
{
	string s = "";
	int n = str.length();
	for (int i = 0; i < n; i++)
	{
		if (str[i] == '\\' || str[i] == '/' || str[i] == ':' || str[i] == '*' || str[i] == '?'
			|| str[i] == '"' || str[i] == '>' || str[i] == '<' || str[i] == '|')
		{
			s += '_';
		}
		else
		{
			s += str[i];
		}
	}
	return s;
}
// strinh to char*
char* toCharArray(string str)
{
	int n = str.length();
	char* arr = new char[n + 1];
	memset(arr, 0, n + 1);
	for (int i = 0; i < n; i++)
	{
		arr[i] = str[i];
	}
	return arr;
}
// khong con dung nua
bool isBinaryFile(string str)
{
	int n = bin_ext.size();
	for (int i = 0; i < n; i++)
	{
		if (bin_ext[i] == str)
		{
			return true;
		}
	}
	return false;
}


// truyen du lieu giua webserer va browser
void Transfer(CSocket& client, CSocket& server, cacheInfo info, recvDataInfo dataInfo)
{
	if (dataInfo.stream == BYTE_STREAM) // luong byte
	{
		//nhan tung byte
		char c = 0;
		long long nByteRecv = 0;
		int temp = 0;
		while (nByteRecv < dataInfo.length)
		{
			temp = server.Receive((char*)& c, 1, 0);
			if (temp > 0)
			{
				client.Send(&c, 1, 0);
				nByteRecv += temp;
			}
			c = 0;
		}
	}
	else // luong text
	{
		if (info.is_cache == true) // neu da cache
		{
			//doc cache va gui cho browser
			fstream f(info.file, ios::in);
			string s;
			if (f.is_open())
			{
				while (!f.eof())
				{
					getline(f, s);
					if (s != "")
					{
						client.Send(s.c_str(), s.length(), 0);
						s = "";
					}
				}
			}
		}
		else
		{
			//chua cache thi cache
			fstream f(info.file, ios::app);
			if (dataInfo.way == CHUNKED)
			{
				char buf[BUFSIZ + 1];
				memset(buf, 0, BUFSIZ + 1);
				while (true)
				{
					server.Receive(buf, BUFSIZ, 0);
					int len = strlen(buf);
					if (len > 0)
					{
						client.Send(buf, len, 0);
						f << buf;
						if (strstr(buf, "0\r\n\r\n") != null) // nhan den khi gap cai nay thi dung
						{
							break;
						}
						memset(buf, 0, len);
					}
				}
			}
			else
			{
				//chua cache thi tao cache va luu lai
				long long nByteRecv = 0;
				char buf[BUFSIZ + 1];
				memset(buf, 0, BUFSIZ + 1);
				int temp = 0;
				while (nByteRecv < dataInfo.length)
				{
					temp = server.Receive(buf, BUFSIZ, 0);
					if (temp > 0)
					{
						nByteRecv += temp;
						client.Send(buf, temp, 0);
						f << buf;
					}
					memset(buf, 0, strlen(buf));
				}
			}
			f.close();
		}
	}
}

//Luong nhan du lieu
//Cach truyen du lieu
//Do dai du lieu
recvDataInfo getDataInfo(string str, cacheInfo CacheInfo)
{
	recvDataInfo info;
	if (strstr(str.c_str(), "\r\nContent-Encoding: ") != null) // luong Byte
	{
		info.stream = BYTE_STREAM;
	}
	else
	{
		if (CacheInfo.is_cache == true) // TEXT moi cache nen co cache tuc la luong text
		{
			info.stream == TEXT_STREAM;
		}
		else
		{
			if (CacheInfo.file == "") // nghia la ko cache thi luong la byte
			{
				info.stream == BYTE_STREAM;
			}
			else //  nghia la du lieu se cache nen luong la text
			{
				info.stream == TEXT_STREAM;
			}
		}
	}
	long long length = getLength(str); // lay do dai cua du lieu truyen ve
	if (length == -1) // way = chunked
	{
		info.way = CHUNKED;
		info.length = -1;
	}
	else if(length == -2) // khong can truyen body
	{
		info.length == -2;
		info.way = null;
		info.stream = null;
	}
	else // se nhan den khi du so byte
	{
		info.length = length;
		info.way = LENGTH;
	}
	return info;
}

//lay do dai du lieu se nhan
long long getLength(string str)
{
	// neu la kieu chunked
	if (strstr(str.c_str(), "\r\nTransfer-Encoding: chunked\r\n") != null)
		return -1;
	//lay ra length
	else
	{
		char a[] = "Content-Length: "; // tim  cho nao co chuoi nay:
		char* t = toCharArray(str);
		char* x = strstr(t, a);
		if (x == null)
			return -2;
		int n = strlen(x);
		char* k = (char*)malloc(n + 1);
		//copy cho toi khi gap \r\n
		for (int i = 0; i < n - 1; i++)
		{
			if (x[i] != '\r' && x[i + 1] != '\n')
			{
				k[i] = x[i];
			}
			else
			{
				k[i] = '\0';
				break;
			}
		}
		char* kq = (char*)malloc(strlen(x) - strlen(a) + 1); // lay chuoi so trong chuoi vau cat o tren
		strcpy(kq, k + strlen(a));							//
		return atoi(kq);
	}
}


//Khoi tao server
void InitServer()
{
	//load blacklist
	fstream f("blacklist.conf", ios::in);
	if (f.is_open())
	{
		string s;
		while (!f.eof())
		{
			getline(f, s);
			if (s != "")
			{
				blacklist.push_back(s);
			}
		}
		f.close();
	}
	// khong dung nua
	bin_ext.push_back(".jpg");
	bin_ext.push_back(".jpeg");
	bin_ext.push_back(".gif");
	bin_ext.push_back(".png");
	bin_ext.push_back(".asf");
	bin_ext.push_back(".raw");
	bin_ext.push_back(".ico");
	bin_ext.push_back(".svg");
	bin_ext.push_back(".JPG");
	bin_ext.push_back(".JPEG");
	bin_ext.push_back(".GIF");
	bin_ext.push_back(".PNG");
	bin_ext.push_back(".ASF");
	bin_ext.push_back(".RAW");
	bin_ext.push_back(".ICO");
	bin_ext.push_back(".SVG");
	bin_ext.push_back(".pdf");
	bin_ext.push_back(".PDF");
	bin_ext.push_back(".exe");
	bin_ext.push_back(".EXE");
	bin_ext.push_back(".mp3");
	bin_ext.push_back(".MP3");
	bin_ext.push_back(".mp4");
	bin_ext.push_back(".MP4");
}