#include <stdio.h>
#include <iostream>

using namespace std;

struct data
{
	int x1;
	int x2;
};

void main()
{
	string str = "http://taimienphi.vn?css";
	string s = "";
	int n = str.length();
	for (int i = 0; i < n; i++)
	{
		if (str[i] == '\\' || str[i] == '/' || str[i] == ':' || str[i] == '*' || str[i] == '?'
			|| str[i] == '"' || str[i] == '>' || str[i] == '<' || str[i] == '|')
		{
			s += '_';
		}
		else
		{
			s += str[i];
		}
	}
	cout << s;
	system("pause");
}